package Sintactico;


public class Principal{
	
	public static void main(String args[]){
		Sintactico sint=new Sintactico();
		sint.ejercicio2();
	}
	

}
